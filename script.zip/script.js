// console.log("Hello, World!");
// console.log("This is a test script.");  


// const clientId= '4e05fd2f98ee4199bc6d1cf5e7d83cbd'; // Get this after user logs in
// const redirect_uri = 'http://127.0.0.1:3000/index.html'; // Your redirect URI

// const scopes = 'user-read-private user-read-email';

// const loginUrl = `https://accounts.spotify.com/authorize?client_id=${clientId}&response_type=code&redirect_uri=${encodeURIComponent(redirect_uri)}&scope=${encodeURIComponent(scopes)}`;

// document.addEventListener('DOMContentLoaded',()=>{
//   const loginbutton = document.querySelector('.login');
//   if(loginbutton){
//     loginbutton.addEventListener('click',()=>{
//       window.location.href=loginUrl;
//     });
//   }
//   else{
//     console.error('Login button not found!');
//   }

// });

// const token = 'http GET https://api.spotify.com/v1/browse/new-releases'; // Your manual token

// fetch('http GET https://api.spotify.com/v1/browse/new-releases', {
//   headers: {
//     'Authorization': `Bearer ${token}`
//   }
// })
// .then(res => res.json())
// .then(data => {
  
//     console.log('Full API Response:', data);  // 👈 Add this line first
//   // data.albums.items.forEach(album => {
//   //   console.log(`🎵 Album: ${album.name} — Artist: ${album.artists[0].name}`);
//   // });
// })
// .catch(err => {
//   console.error('Error fetching new releases:', err);
// });



// async function getsongs() {
  
//   let a= await fetch("http://127.0.0.1:3000/songs.mp3/");
//   let response = await a.text();
//   let div = document.createElement("div");
//   div.innerHTML = response;
//   let as = div.getElementsByTagName("a");
//   let songs = []
//   for (let index = 0; index < as.length; index++) {
//     const element = as[index];
//     if(element.href.endsWith(".mp4")){
//       songs.push(element.href);
//     }
    
//   }
//   return songs
// }

// async function main(){
//   let songs = await getsongs();
//    console.log(songs);

//    var audio = new Audio(songs[0]);
//     audio.play();
   
// }

// main(); 

// fetxhing the songs

let songs;
async function getsongs() {
  let a = await fetch("http://127.0.0.1:3000/songs.mp3/");
  let response = await a.text();
  let div = document.createElement("div");
  div.innerHTML = response;
  let as = div.getElementsByTagName("a");
  songs = [];

  for (let index = 0; index < as.length; index++) {
    const element = as[index];
    if (element.href.endsWith(".mp3")) {
      // Use the correct split and check result
      let parts = element.href.split("/songs.mp3/");
      if (parts[1]) {
        songs.push(parts[1]);
      }
    }
  }

  return songs;
}


//show all the songs in the playlist

async function main() {
   songs = await getsongs();
  
  console.log(songs);
  
  
  let songsul = document.querySelector(".songlist").getElementsByTagName("ul")[0];
  for (const song of songs) {
    // songsul.innerHTML = songsul.innerHTML + `<li> ${song.replaceAll("%20"," ")}</li>`;
    let cleanName = decodeURIComponent(song)        // decode %20 → space
    .replace(/\.(mp3|mp4)$/i, "")                 // remove .mp3 or .mp4
    .replace(/\(.*?\)/g, "")                      // remove anything in parentheses
    .trim();                                      // remove trailing spaces
    
    let [artist = "unknow artist" , title = cleanName] = cleanName.split(" - ");
    
    // let imgSrc = `covers/${cleanName}.jpg`;  // or a fallback like 'default.jpg'
    
    songsul.innerHTML += `<li data-src="http://127.0.0.1:3000/songs.mp3/${song}"> 
    <img  class="invert "  src="music.svg" alt ="cover">
    
    <div class="info ">
    <div class="songn">${title}</div>
    <div class="artistn">${artist}</div>
    </div>
    <img  class="playi invert"  src="play.svg" alt="">
    
    
    
    </li>`;
    
    
  } 
  if (songs.length === 0) {
    console.log("No songs found!");
    return;
  }
  
  const audioPlayer = document.getElementById("audioPlayer")
  const play = document.getElementById("play")
  const playicon = document.getElementById("playicon")
  const songInfo = document.querySelector(".songinfo"); // the song label
  
  
  
  document.querySelectorAll(".songlist li ").forEach(songItem => {
    songItem.addEventListener('click',function(e){
      const songsrc = songItem.getAttribute('data-src');
      
      if(e.target.classList.contains("playi") || songItem.contains(e.target)){
        // audioPlayer.songsul[0];
        audioPlayer.src = songsrc;
          audioPlayer.play();
          playicon.src = "pause.svg";
          
        
        const title = songItem.querySelector(".songn")
        const artist = songItem.querySelector(".artistn");
        songInfo.innerHTML = `${title.textContent} - ${artist.textContent}`
      }
      
    });
    
  });
  
  // attach a eventlistner to playbar 
  play.addEventListener("click", () => {
    if(!audioPlayer.src || audioPlayer.src.trim()=== ""){
    let  firstsong = document.querySelector(".songlist li ")
      if(firstsong){
      const songsrc =firstsong.getAttribute("data-src");
      const title = firstsong.querySelector(".songn").textContent;
      const artist = firstsong.querySelector(".artistn").textContent;

      audioPlayer.src = songsrc;

      audioPlayer.addEventListener("loadedmetadata",()=>{
        audioPlayer.play();
        playicon.src = "pause.svg";
        songInfo.innerHTML = `${title} - ${artist}`;
        
      },{once:true})
      }
    }else
      // audioPlayer.songs[0]
      if(audioPlayer.paused){
        audioPlayer.play();
        playicon.src = "pause.svg" 
      }else{
        audioPlayer.pause();
        playicon.src = "play2.svg"
      }
    });
    
    // funtion to convert seconds into format 
    function formattime(seconds){
         const  min = Math.floor(seconds / 60);
         const  secs = Math.floor(seconds % 60);
         const formatmins  = min < "10" ? "0" +  min:min; 
         const formatsecs  = secs < "10" ? "0" +  secs:secs; 
         return (`${formatmins}:${formatsecs}`)
    }

    // listen to the timeupdate 
    audioPlayer.addEventListener("timeupdate", ()=>{
     const currentFormatted = formattime(audioPlayer.currentTime);
  document.querySelector(".timestamp").innerHTML = currentFormatted;
    })
      
 
    audioPlayer.addEventListener("loadedmetadata", () => {
  const totalFormatted = formattime(audioPlayer.duration);
  document.querySelector(".totaltime").innerHTML = totalFormatted;
});
// envent listner to the playbvar

audioPlayer.addEventListener("timeupdate", () => {
  const currentFormatted = formattime(audioPlayer.currentTime);
  document.querySelector(".timestamp").innerHTML = currentFormatted;

  const progress = (audioPlayer.currentTime / audioPlayer.duration) * 100;

  const circle = document.querySelector(".circle");
    const songTime = document.querySelector(".songtime");
  if (!isNaN(progress)) {
    circle.style.left = `${progress}%`;

    songTime.style.background =`linear-gradient(to right,rgb(249, 249, 249) ${progress}%, #757171 ${progress}%)`;
  }
});

  //  add the eventlistner to the aongtime or seekbar 
  document.querySelector(".songtime").addEventListener("click" , e=>{
    let percent = ( e.offsetX/e.target.getBoundingClientRect().width)*100;
       document.querySelector(".circle").style.left = percent + "%";
      audioPlayer.currentTime = ((audioPlayer.duration)*percent)/100
  })

  // add eventlisnerto hamburger 
  document.querySelector(".hamburger").addEventListener("click", ()=>{
     
   document.querySelector(".left").style.display = "block"
   document.querySelector(".close").style.display = "block"
   document.querySelector(".hamburger").style.display = "none"
  })

  document.querySelector(".close").addEventListener("click", ()=> {
    document.querySelector(".left").style.display = "none"
    document.querySelector(".close").style.display = "none"
    document.querySelector(".hamburger").style.display = "block"
  })

  // Event listenr to the settigns after 480 px
const settings = document.querySelector(".settings");
const settingslist = document.querySelector(".settingslist");


settings.addEventListener("click", () => {
  if (settingslist.style.visibility === "visible") {
    settingslist.style.visibility = "hidden";  // use '=' not '=='
  } else {
    settingslist.style.visibility = "visible";
  }
});

// add event listenr to the previous and forwrd buton 

playprevious.addEventListener("click", () => {
    let current = audioPlayer.src ? audioPlayer.src.split("/").slice(-1)[0] : null;
    let index = songs.indexOf(current);
    if (index > 0) {
        audioPlayer.src = "http://127.0.0.1:3000/songs.mp3/" + songs[index - 1];
        audioPlayer.play();
        playicon.src = "pause.svg";
    }
});

playforwerd.addEventListener("click", () => {
    let current = audioPlayer.src ? audioPlayer.src.split("/").slice(-1)[0] : null;
    let index = songs.indexOf(current);
    if (index > -1 && index < songs.length - 1) {
        audioPlayer.src = "http://127.0.0.1:3000/songs.mp3/" + songs[index + 1];
        audioPlayer.play();
        playicon.src = "pause.svg";
   

          const songItem = document.querySelector(`li[data-src$="${newSong}"]`);
        const title = songItem.querySelector(".songn").textContent;
        const artist = songItem.querySelector(".artistn").textContent;
        songInfo.innerHTML = `${title} - ${artist}`;

    }
    
});
  }
document.addEventListener("DOMContentLoaded", () => {
  main();
});





